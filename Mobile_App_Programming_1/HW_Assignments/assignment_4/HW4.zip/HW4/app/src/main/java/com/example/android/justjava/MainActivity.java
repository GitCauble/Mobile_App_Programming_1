/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.justjava;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;

import java.text.NumberFormat;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void submitOrder(View view) {

        //// question 1
        RadioButton trueRadio1 = (RadioButton) findViewById(R.id.true1_button);
        boolean hasTrue1 = trueRadio1.isChecked();

        RadioButton falseRadio1 = (RadioButton) findViewById(R.id.false1_button);
        boolean hasFalse1 = falseRadio1.isChecked();

        //// question 2
        // Get user's month input
        EditText nameField = (EditText) findViewById(R.id.name_field);
        Editable nameEditable = nameField.getText();
        String name = nameEditable.toString();
        //String October = "October";

        boolean hasOctober;

        if (name.equals("October")) {
            hasOctober = true;
        } else {
            hasOctober = false;
        }

        //// question 3
        CheckBox red_color_CheckBox = (CheckBox) findViewById(R.id.color_red);
        boolean has_red = red_color_CheckBox.isChecked();
        CheckBox white_color_CheckBox = (CheckBox) findViewById(R.id.color_white);
        boolean has_white = white_color_CheckBox.isChecked();
        CheckBox green_color_CheckBox = (CheckBox) findViewById(R.id.color_green);
        boolean has_green = green_color_CheckBox.isChecked();
        CheckBox blue_color_CheckBox = (CheckBox) findViewById(R.id.color_blue);
        boolean has_blue = blue_color_CheckBox.isChecked();

        //// question 4

        RadioButton trueRadio2 = (RadioButton) findViewById(R.id.true2_button);
        boolean hasTrue2 = trueRadio2.isChecked();

        RadioButton falseRadio2 = (RadioButton) findViewById(R.id.false2_button);
        boolean hasFalse2 = falseRadio2.isChecked();


        //// question 5

        RadioButton trueRadio3 = (RadioButton) findViewById(R.id.true3_button);
        boolean hasTrue3 = trueRadio3.isChecked();

        RadioButton falseRadio3 = (RadioButton) findViewById(R.id.false3_button);
        boolean hasFalse3 = falseRadio3.isChecked();


        //// question 6

        RadioButton trueRadio4 = (RadioButton) findViewById(R.id.true4_button);
        boolean hasTrue4 = trueRadio4.isChecked();

        RadioButton falseRadio4 = (RadioButton) findViewById(R.id.false4_button);
        boolean hasFalse4 = falseRadio4.isChecked();


        //// question 7

        RadioButton trueRadio5 = (RadioButton) findViewById(R.id.true5_button);
        boolean hasTrue5 = trueRadio5.isChecked();

        RadioButton falseRadio5 = (RadioButton) findViewById(R.id.false5_button);
        boolean hasFalse5 = falseRadio5.isChecked();


        //// question 8

        RadioButton trueRadio6 = (RadioButton) findViewById(R.id.true6_button);
        boolean hasTrue6 = trueRadio6.isChecked();

        RadioButton falseRadio6 = (RadioButton) findViewById(R.id.false6_button);
        boolean hasFalse6 = falseRadio6.isChecked();


        //// question 9

        RadioButton trueRadio7 = (RadioButton) findViewById(R.id.true7_button);
        boolean hasTrue7 = trueRadio7.isChecked();

        RadioButton falseRadio7 = (RadioButton) findViewById(R.id.false7_button);
        boolean hasFalse7 = falseRadio7.isChecked();


        //// question 10

        RadioButton trueRadio8 = (RadioButton) findViewById(R.id.true8_button);
        boolean hasTrue8 = trueRadio8.isChecked();

        RadioButton falseRadio8 = (RadioButton) findViewById(R.id.false8_button);
        boolean hasFalse8 = falseRadio8.isChecked();



        // Calculate the score
        int score = calculateScore(hasTrue1, hasFalse1, hasOctober, has_red, has_white, has_green,
                has_blue, hasTrue2, hasFalse2, hasTrue3, hasFalse3, hasTrue4, hasFalse4, hasTrue5,
                hasFalse5, hasTrue6, hasFalse6, hasTrue7, hasFalse7, hasTrue8, hasFalse8);

        // Display the score summary on the screen
        String message = createOrderSummary(score);

        TextView textView=(TextView)findViewById(R.id.price_print);
        textView.setText(message);



    }


    private int calculateScore(boolean addTrue1, boolean addFalse1, boolean addOctober,
                               boolean add_red, boolean add_white, boolean add_green,
                               boolean add_blue, boolean addTrue2, boolean addFalse2,
                               boolean addTrue3, boolean addFalse3, boolean addTrue4,
                               boolean addFalse4, boolean addTrue5, boolean addFalse5,
                               boolean addTrue6, boolean addFalse6, boolean addTrue7,
                               boolean addFalse7, boolean addTrue8, boolean addFalse8) {
        int basePrice = 0;

        // question 1
        if (addTrue1) {
            basePrice = basePrice + 10;
        }
        // question 2
        if (addOctober) {
            basePrice = basePrice + 10;
        }
        // question 3
        if (addFalse1) {
            basePrice = basePrice + 0;
        }
        if (add_red & add_white & add_blue) {
            basePrice = basePrice + 10;
        }
        if (add_green) {
            basePrice = basePrice + 0;
        }
        // question 4
        if (addTrue2) {
            basePrice = basePrice + 10;
        }
        if (addFalse2) {
            basePrice = basePrice + 0;
        }
        // question 5
        if (addTrue3) {
            basePrice = basePrice + 10;
        }
        if (addFalse3) {
            basePrice = basePrice + 0;
        }
        // question6
        if (addTrue4) {
            basePrice = basePrice + 10;
        }
        if (addFalse4) {
            basePrice = basePrice + 0;
        }
        // question 7
        if (addTrue5) {
            basePrice = basePrice + 10;
        }
        if (addFalse5) {
            basePrice = basePrice + 0;
        }
        // question 8
        if (addTrue6) {
            basePrice = basePrice + 10;
        }
        if (addFalse6) {
            basePrice = basePrice + 0;
        }
        // question 9
        if (addTrue7) {
            basePrice = basePrice + 10;
        }
        if (addFalse7) {
            basePrice = basePrice + 0;
        }
        // question 10
        if (addTrue8) {
            basePrice = basePrice + 0;
        }
        if (addFalse8) {
            basePrice = basePrice + 10;
        }


        return  basePrice;
    }


    private String createOrderSummary( int score) {
        String priceMessage = "Your Score Is:";
        priceMessage += "\n" + score;
        priceMessage += "\n" + getString(R.string.thank_you);
        return priceMessage;
    }



}
